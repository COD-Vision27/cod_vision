<div align="center">

# 🧪 Daedalus

**RoboMaster 视觉算法验证模拟器**

*为算法而生的实验场，让自瞄在上场前就经历真实考验*

[![Rust](https://img.shields.io/badge/Rust-Stable-orange.svg?style=for-the-badge&logo=rust)](https://www.rust-lang.org/)
[![Bevy](https://img.shields.io/badge/Bevy-Engine-3A3A3A.svg?style=for-the-badge&logo=bevy)](https://bevyengine.org/)
[![ROS2](https://img.shields.io/badge/ROS2-Integrated-22314E.svg?style=for-the-badge&logo=ros)](https://www.ros.org/)

</div>

## 🚀 功能亮点

* 🎯 **全要素战场环境仿真**
  覆盖能量机关、前哨站、大/小装甲模块等 RoboMaster 核心视觉目标，提供高保真的外观与状态模拟。

* 🤖 **多机器人模型与行为**
  支持步兵（Infantry）与英雄（Hero）机器人的移动、底盘旋转、云台控制与弹丸发射。

* 🔄 **算法-数据-控制完整闭环**
  原生打通 **图像采集 → 目标标注 → ROS2/Talos 推理 → 云台反馈**，实现“看-算-打”全流程验证。

* ⚔️ **多主体动态对抗模拟**
  己方与多个假人独立控制，支持 Tab 键实时切换，真实构造遮挡、对抗与复杂战场场景。

* 🚀 **双通道实时通信接口**
    - **ROS2 原生集成**：直接发布图像、TF 与位姿话题，零成本接入现有自瞄系统
    - **Talos 零拷贝 IPC**：与 [talos](https://github.com/Blackjack200/talos) 通过共享内存通信，支持实时姿势发布与云台命令订阅

* ⚡️ **高性能实时渲染管线**
  基于 Bevy 引擎，支持 CPU/GPU 渲染，保证高帧率与严格的时间一致性。

---

## 🎨 功能覆盖与开发路线

### ✅ 已实现

#### 🏟️ 战场环境仿真

* **能量机关完整仿真** - 大/小能量机关的激活流程与视觉状态模拟
* **前哨站完整仿真** - 前哨站外观与装甲模块状态模拟
* **装甲模块建模与渲染** - 大、小装甲模块全部图案双色灯条显示

#### 🤖 机器人模型与行为

* **步兵机器人（Infantry）** - 移动、底盘旋转、云台控制、17mm弹丸发射
* **英雄机器人（Hero）** - 大装甲模块专属配置、移动与发射行为
* **物理动力学模拟** - 基于物理的移动、旋转与碰撞响应

#### 🔌 通信接口集成

* **ROS2 原生集成** - 发布 `/image_raw`、`/camera_info`、`/tf` 等话题，订阅 `/rm_gimbal/cmd`；SP 新版轨迹接口为 `/sp_vision/sim/plan`
* **Talos 共享内存 IPC** - 与 C++ talos-cpp 零拷贝通信，发布 odom/gimbal/muzzle/camera 姿势，订阅云台控制命令

#### 📊 工具与接口

* **控制指令订阅** - 支持 ROS2 与 Talos 双通道控制指令接入
* **假人控制切换** - Tab 键实时切换活动假人，支持多机器人测试场景

#### ⚡️ 渲染与性能

* **高性能实时渲染管线** - 基于 Bevy 引擎，CPU/GPU 渲染支持，保证高帧率与时间一致性
* **多视角观测系统** - 自由视角、第一人称、第三人称视角切换（F3键）

---

### 🔄 近期计划

* **ROS2 自定义相机外参支持**

---

### 🚀 规划中功能

* **多机器人协同仿真**（步兵 / 英雄 / 哨兵）
* **弹道模拟与落点校准验证**
* **相机成像参数模拟**（曝光、白平衡、畸变）
* **多光照条件与环境变化模拟**

---

## 💡 使用说明

SP Vision 新版自瞄的独立 ROS2 接入、解析相机标定、启动和闭环测试见 [接入说明](../sp_vision_ros/README.md)、[使用报告](../sp_vision_ros/docs/使用报告.md) 和 [测试说明](../sp_vision_ros/docs/测试说明.md)。

### ROS2 接口

**发布话题**

* `/camera_info`
* `/image_raw` / `image_compressed`
* `/tf`
* `/gimbal_pose`
* `/odom_pose`
* `/camera_pose`

**订阅话题**

* `/rm_gimbal/cmd`（保留原接口）
* `/sp_vision/sim/plan`（SP Planner 两轴角度/速度/加速度、控制和开火）

另外发布 `/sp_vision/sim/frame_tf`，它与 RGB 图像使用同一个渲染帧的时间戳，供 SP 适配器精确配对。实机 `sp_vision_25` 无需改动。

### Talos 共享内存接口

**发布姿势**（零拷贝共享内存）

* `odom` - 底盘里程计姿势
* `gimbal` - 云台旋转姿势
* `muzzle` - 枪口偏移姿势
* `camera` - 相机外参姿势

**订阅命令**

* `gimbal_cmd` - 云台控制命令（含开火建议）

### 自瞄精度评测（JSONL）

仿真器可在不改变 Talos 共享内存 ABI 的情况下输出逐发遥测。配置文件中的
`[telemetry]` 默认关闭；短实验也可以用环境变量临时开启：

```bash
DAEDALUS_AUTO_AIM=1 \
DAEDALUS_METRICS_PATH=artifacts/daedalus_metrics.jsonl \
cargo run --release
```

On a CI host without a display, run the same command under the host's virtual
display wrapper (for example `xvfb-run -a`); the simulator currently does not
claim a separate `--headless` command-line mode.

每行都有 `schema=daedalus.simulation_metrics` 和 `version=1`。事件包括
`gimbal_command`、`shot_fired`、`armor_hit`、`rune_hit`、`shot_finished` 和
`session_summary`；在 Talos 模式下，`ground_truth_target` 事件提供与 Talos `frame_seq` 对齐的目标中心线真值；
仅启用 ROS2 捕获时该事件不会产生。其他事件携带
仿真帧号、纳秒时间戳、弹丸起点/方向以及目标装甲标签；`shot_fired.talos_*` 是发射时
最近一次已观测到的 Talos stamp，需用时间戳与真值事件做最终配对。
`projectile_armor_accuracy` 是标准弹丸命中装甲数/标准弹丸发射数的仿真指标（飞镖单独
统计）；没有连接自瞄消费者或目标标注时，它不能替代真实视觉 precision/recall。
`DAEDALUS_AUTO_AIM=1` 明确启用 Talos/ROS2
命令消费，默认手动运行仍保持关闭。

`ground_truth_target` 事件额外包含目标实体标识、目标类型/数量、控制状态、Bevy 世界坐标，
以及 `position_ros`（`ros_z_up` 坐标约定）。Talos 模式还会为每个 `ArmorRoot` 写出独立的
`ground_truth_armor` 事件，避免网格子实体重复计数。当目标位于相机前方时，还会写入
`camera_position_ros`、`yaw_deg`、`pitch_deg`、`pixel_u`、`pixel_v` 和 `visible`，这些字段
与同一 `frame_seq` 的视觉估计事件配对使用。评估工具只消费显式的 `yaw_deg`/`pitch_deg`，
不会把物理事件推导为视觉指标：

```bash
python3 tools/metrics_summary.py artifacts/daedalus_metrics.jsonl \
  --angle-threshold-deg 2
```

### 离线回放退出控制

离线回放可以用命令行限制运行长度，便于生成可重复的短实验报告：

```bash
# 运行 300 个仿真帧后退出
cargo run --release -- --frames 300

# 运行 10 个仿真秒后退出
cargo run --release -- --duration-secs 10
```

`--frames` 与 `--duration-secs` 不能同时使用；未指定时保持交互式持续运行。达到上限后模拟器通过正常的 Bevy 退出流程结束，已启用遥测时仍会写出最后一条 `session_summary` 事件。

---

### 控制方式

#### 己方 Infantry

| 功能   | 按键              |
|------|-----------------|
| 移动   | `W` `A` `S` `D` |
| 底盘旋转 | `Q` `E`         |
| 发射弹丸 | `Space`         |
| 云台旋转 | `↑` `↓` `←` `→` |

#### 假人 Infantry

| 功能   | 按键              |
|------|-----------------|
| 移动   | `I` `J` `K` `L` |
| 底盘旋转 | `U` `O`         |
| 云台旋转 | `F` `V` `C` `B` |

#### 假人切换

* **Tab**：切换活动假人控制权（在多个假人之间循环切换）

#### 自由视角

| 功能   | 操作                        |
|------|---------------------------|
| 移动   | `W` `A` `S` `D` + `N` `J` |
| 视角旋转 | 鼠标拖动                      |

---

### 视角切换

* **F3**：切换视角模式

    * 自由视角：全局观察，适合算法调试
    * 第一人称：操作手视角
    * 第三人称：机器人行为分析

---

### 实用功能

* **F2**：截图
* **F4**：调试信息开关
* **F5**：自瞄订阅开关

---

## 📝 项目信息

* **作者**：Blackjack200
* **团队**：Actor&Thinker 战队
* **技术栈**：Rust · Bevy · ROS2(r2r) · Talos IPC
* **交流方式**：GitHub Issues / Pull Requests
* **开源协议**：AGPL v3

---

## 🌄 演示

<div align="center">
    <img src="demo.png" width="75%">
</div>

---

## 📜 开源协议说明

本项目采用 **AGPL v3** 协议。

我们选择开放仿真基础设施，是因为 RoboMaster 视觉算法的发展依赖于**可复现的实验环境**。
通过开放核心能力，希望为社区提供一个可靠的起点，让更多战队能够在此基础上进行验证、扩展与创新。
