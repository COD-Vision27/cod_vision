#![allow(dead_code)]
mod capture;
mod components;
mod config;
mod handler;
mod metrics;
mod robomaster;
mod scene;
mod setup;
mod statistic;
mod systems;
mod telemetry;
mod util;

#[cfg(feature = "ros2")]
mod ros2;
#[cfg(feature = "talos")]
mod talos;

use avian3d::prelude::*;
use bevy::diagnostic::{FrameTimeDiagnosticsPlugin, LogDiagnosticsPlugin};
use bevy::prelude::*;
use bevy::render::settings::{InstanceFlags, RenderCreation, WgpuSettings, WgpuSettingsPriority};
use bevy::render::{RenderPlugin, RenderSystems};
use bevy::window::PresentMode;
use bevy::winit::WinitSettings;
use bevy_inspector_egui::bevy_egui::EguiPlugin;
use bevy_inspector_egui::quick::WorldInspectorPlugin;
use std::sync::atomic::AtomicBool;

use crate::components::{CameraMode, FollowingType, ProjectileCooldown, SubscribeAutoAim};
use crate::config::{ConfigPlugin, SimulationConfig};
use crate::handler::{on_activate, on_hit};
use crate::metrics::{SimulationMetrics, advance_metrics_frame};
use crate::robomaster::prelude::RoboMasterPlugins;
use crate::setup::setup;
use crate::statistic::ProjectileStatistics;
use crate::systems::{
    ChassisObservationFrame, ControllerState, GameplaySystems, PreviousKinematicState,
    change_appearance, cleanup_projectiles, clear_controller_input, controller_dart_just_pressed,
    controller_shoot_pressed, dart_launch, following_controls, freecam_controls, gimbal_controls,
    gimbal_pid_controls, projectile_aerodynamics, projectile_launch, remote_gimbal_controls,
    remote_vehicle_controls, sample_gamepad_controller, sample_keyboard_controller,
    screenshot_on_f2, screenshot_saving, setup_projectile, switch_slapper_control, uav_launch,
    update_auto_aim_subscription, update_chassis_observation, update_help_text, vehicle_controls,
};
use bevy_metalfx::MetalFxPlugin;
use clap::Parser;

#[cfg(feature = "ros2")]
use crate::ros2::plugin::ROS2Plugin;
#[cfg(feature = "talos")]
use talos::TalosPlugin;

fn present_mode_from_config(value: &str) -> Option<PresentMode> {
    match value.trim().to_ascii_lowercase().as_str() {
        "auto_vsync" | "vsync" => Some(PresentMode::AutoVsync),
        "auto_no_vsync" | "no_vsync" | "novsync" => Some(PresentMode::AutoNoVsync),
        "fifo" => Some(PresentMode::Fifo),
        "fifo_relaxed" | "fifo-relaxed" => Some(PresentMode::FifoRelaxed),
        "mailbox" => Some(PresentMode::Mailbox),
        "immediate" => Some(PresentMode::Immediate),
        _ => None,
    }
}

fn is_wsl() -> bool {
    std::env::var_os("WSL_DISTRO_NAME").is_some()
        || std::env::var_os("WSL_INTEROP").is_some()
        || std::fs::read_to_string("/proc/sys/kernel/osrelease")
            .map(|release| release.to_ascii_lowercase().contains("microsoft"))
            .unwrap_or(false)
}

fn render_plugin_for_platform() -> RenderPlugin {
    if cfg!(target_os = "linux") && is_wsl() {
        return RenderPlugin {
            render_creation: RenderCreation::Automatic(Box::new(WgpuSettings {
                instance_flags: InstanceFlags::default()
                    | InstanceFlags::ALLOW_UNDERLYING_NONCOMPLIANT_ADAPTER,
                priority: WgpuSettingsPriority::Functionality,
                ..default()
            })),
            ..default()
        };
    }

    RenderPlugin::default()
}

fn fixed_time_from_config(config: &SimulationConfig) -> Time<Fixed> {
    Time::<Fixed>::from_hz(config.physics.fixed_hz.max(1.0))
}

fn parse_positive_duration(value: &str) -> Result<f64, String> {
    let seconds = value
        .parse::<f64>()
        .map_err(|error| format!("invalid duration {value:?}: {error}"))?;
    if seconds.is_finite() && seconds > 0.0 {
        Ok(seconds)
    } else {
        Err("duration must be a finite value greater than zero".to_string())
    }
}

#[derive(Parser, Debug)]
#[command(
    name = "daedalus",
    about = "Offline mobile-robot visual tracking simulation"
)]
struct Cli {
    /// Exit after this many rendered simulation frames.
    #[arg(long, conflicts_with = "duration_secs", value_parser = clap::value_parser!(u64).range(1..))]
    frames: Option<u64>,

    /// Exit after this many simulated seconds.
    #[arg(
        long,
        value_name = "SECONDS",
        conflicts_with = "frames",
        value_parser = parse_positive_duration
    )]
    duration_secs: Option<f64>,
}

#[derive(Resource, Debug)]
struct RunLimit {
    max_frames: Option<u64>,
    duration_secs: Option<f64>,
    elapsed_frames: u64,
}

impl RunLimit {
    fn from_cli(cli: Cli) -> Self {
        Self {
            max_frames: cli.frames,
            duration_secs: cli.duration_secs,
            elapsed_frames: 0,
        }
    }
}

fn enforce_run_limit(
    mut limit: ResMut<RunLimit>,
    time: Res<Time>,
    mut exit: MessageWriter<AppExit>,
) {
    limit.elapsed_frames = limit.elapsed_frames.saturating_add(1);
    let frame_limit_reached = limit
        .max_frames
        .is_some_and(|max_frames| limit.elapsed_frames >= max_frames);
    let duration_limit_reached = limit
        .duration_secs
        .is_some_and(|seconds| time.elapsed_secs_f64() >= seconds);
    if frame_limit_reached || duration_limit_reached {
        exit.write(AppExit::Success);
    }
}

#[cfg(feature = "talos")]
fn should_enable_talos_plugin(app: &App) -> bool {
    #[cfg(feature = "ros2")]
    let ros_capture_active = app
        .world()
        .contains_resource::<crate::ros2::capture::RosCaptureContext>();
    #[cfg(not(feature = "ros2"))]
    let ros_capture_active = false;

    let force_talos_capture = std::env::var("DAEDALUS_FORCE_TALOS_CAPTURE")
        .map(|v| v == "1")
        .unwrap_or(false);

    !ros_capture_active || force_talos_capture
}

fn main() {
    let cli = Cli::parse();
    let config = SimulationConfig::default();
    let present_mode = present_mode_from_config(&config.window.present_mode).unwrap_or_else(|| {
        warn!(
            "Unknown window.present_mode {:?}, falling back to auto_no_vsync",
            config.window.present_mode
        );
        PresentMode::AutoNoVsync
    });
    let mut app = App::new();
    app.add_plugins((
        DefaultPlugins
            .set(WindowPlugin {
                primary_window: Some(Window {
                    present_mode,
                    fit_canvas_to_parent: true,
                    ..default()
                }),
                ..default()
            })
            .set(render_plugin_for_platform()),
        PhysicsPlugins::default(),
    ));
    app.insert_resource(WinitSettings::continuous());

    if config.debug.egui {
        app.add_plugins(EguiPlugin::default());
        if config.debug.inspector {
            app.add_plugins(WorldInspectorPlugin::new());
        }
    }

    app.add_plugins(RoboMasterPlugins)
        .add_plugins(MetalFxPlugin)
        .add_plugins(crate::scene::ScenePlugin)
        .add_plugins(ConfigPlugin)
        .insert_resource(SimulationMetrics::from_config(&config.telemetry))
        .insert_resource(RunLimit::from_cli(cli))
        .init_resource::<CameraMode>()
        .init_resource::<ProjectileStatistics>()
        .init_resource::<ChassisObservationFrame>()
        .init_resource::<PreviousKinematicState>()
        .init_resource::<ControllerState>()
        .register_type::<ProjectileStatistics>()
        .insert_resource(Gravity(Vec3::NEG_Y * 9.81))
        .insert_resource(SubstepCount(config.physics.substep_count))
        .insert_resource(fixed_time_from_config(&config))
        .insert_resource(SubscribeAutoAim(AtomicBool::new(
            auto_aim_from_environment(),
        )))
        .insert_resource(ProjectileCooldown(Timer::from_seconds(
            config.projectile.cooldown,
            TimerMode::Once,
        )))
        .add_systems(Startup, (setup, setup_projectile))
        .add_systems(First, (advance_metrics_frame, enforce_run_limit).chain())
        .add_observer(on_hit)
        .add_observer(on_activate)
        .configure_sets(
            Update,
            (
                GameplaySystems::Input,
                GameplaySystems::GameLogic,
                GameplaySystems::Camera,
                GameplaySystems::Cleanup,
            )
                .chain(),
        )
        .add_systems(
            Update,
            (
                // Input phase
                (
                    clear_controller_input,
                    sample_keyboard_controller,
                    sample_gamepad_controller,
                    systems::sample_sp_scenario,
                    update_auto_aim_subscription,
                    following_controls,
                    switch_slapper_control,
                    vehicle_controls.run_if(|mode: Res<CameraMode>| mode.0 != FollowingType::Free),
                    remote_vehicle_controls,
                    gimbal_controls,
                    gimbal_pid_controls.run_if(|enabled: Res<SubscribeAutoAim>| {
                        enabled.load(std::sync::atomic::Ordering::Acquire)
                    }),
                    remote_gimbal_controls,
                )
                    .chain()
                    .in_set(GameplaySystems::Input),
                // GameLogic phase
                (change_appearance, update_help_text).in_set(GameplaySystems::GameLogic),
                setup::inspect_sp_stickers.in_set(GameplaySystems::GameLogic),
                // Camera phase
                (
                    freecam_controls.run_if(|mode: Res<CameraMode>| mode.0 == FollowingType::Free),
                    systems::update_camera_follow
                        .run_if(|mode: Res<CameraMode>| mode.0 != FollowingType::Free),
                )
                    .in_set(GameplaySystems::Camera)
                    .before(RenderSystems::Render),
                // Cleanup phase
                (
                    cleanup_projectiles,
                    screenshot_on_f2
                        .run_if(|input: Res<ButtonInput<KeyCode>>| input.just_pressed(KeyCode::F2)),
                    screenshot_saving,
                )
                    .in_set(GameplaySystems::Cleanup),
            ),
        )
        .add_systems(
            PostUpdate,
            update_chassis_observation.after(TransformSystems::Propagate),
        )
        .add_systems(
            PostUpdate,
            projectile_launch
                .after(TransformSystems::Propagate)
                .run_if(controller_shoot_pressed),
        )
        .add_systems(
            PostUpdate,
            dart_launch
                .after(TransformSystems::Propagate)
                .run_if(controller_dart_just_pressed),
        )
        .add_systems(PostUpdate, uav_launch.after(TransformSystems::Propagate))
        .add_systems(FixedUpdate, projectile_aerodynamics);

    if config.debug.diagnostics {
        app.add_plugins((
            FrameTimeDiagnosticsPlugin::default(),
            LogDiagnosticsPlugin::default(),
        ));
    }

    #[cfg(feature = "ros2")]
    {
        app.add_plugins(ROS2Plugin::default());
        info!("ROS2 integration enabled");
    }
    #[cfg(not(feature = "ros2"))]
    {
        info!("ROS2 integration disabled");
    }

    #[cfg(feature = "talos")]
    {
        if should_enable_talos_plugin(&app) {
            app.add_plugins(TalosPlugin::default());
            info!("talos integration enabled");
        } else {
            info!(
                "talos integration skipped: ROS2 capture already active \
                 (set DAEDALUS_FORCE_TALOS_CAPTURE=1 to override)"
            );
        }
    }

    app.run();
}

/// Headless Talos/ROS2 runs cannot press F5 to enable command consumption.
/// Opt in explicitly so normal interactive control remains unchanged.
fn auto_aim_from_environment() -> bool {
    std::env::var("DAEDALUS_AUTO_AIM")
        .map(|value| {
            matches!(
                value.trim().to_ascii_lowercase().as_str(),
                "1" | "true" | "yes" | "on"
            )
        })
        .unwrap_or(false)
}
